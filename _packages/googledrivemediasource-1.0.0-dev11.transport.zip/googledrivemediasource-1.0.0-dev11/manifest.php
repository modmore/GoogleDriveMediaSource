<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Proprietary until project completed and paid in full. Afterwards, MIT as included below.

MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.0-rc1
-----------------------------------
Released on 2022-11-03

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '4ce38f8e83605766fdf9ae4e8edb75ff',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/2ba520b11f5a43f4af807367bc952bf2.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'da599f50aa4766c43a9337c1cda9868c',
      'native_key' => 'da599f50aa4766c43a9337c1cda9868c',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/cdf877483735940c4870dc273044890a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '3a22019e327a76d7a118c70ef639505a',
      'native_key' => '3a22019e327a76d7a118c70ef639505a',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/7785a627d16e376a07e7e9239c2d6a71.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '760c5de05159753d553c79dbbf596759',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/6158882fd76066d8afc37747f4f7855f.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);