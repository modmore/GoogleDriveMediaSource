<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.0-pl
----------------------------------
Released on 2023-02-07

- First public release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '83cb141c456f36d49b6590ad7aa9c94f',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/e8539b88e6d200aefedf4fcf552b353f.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '2c555d75412873eafa5d113cf7317cc4',
      'native_key' => '2c555d75412873eafa5d113cf7317cc4',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1dcfb1425e4cabfbc0620727b09fdf23.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '245c5b511ef4d8aa62e5aed03014a57d',
      'native_key' => '245c5b511ef4d8aa62e5aed03014a57d',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/be9321154c3ce558e22642725042614e.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '673f65dc7341561ee54260ae337b937c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/74b4eca717c5431a68d0cc7c0aad5489.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);