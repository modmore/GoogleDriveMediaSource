<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Proprietary until project completed and paid in full. Afterwards, MIT as included below.

MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.0-rc1
-----------------------------------
Released on 2022-11-03

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'fc2a0c3579bcc84bd1b422f5d135cc11',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/e77d3db8ee6e0926ee1b0015b60f173f.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd00328c5815ad4e27e4e5fa1df323080',
      'native_key' => 'd00328c5815ad4e27e4e5fa1df323080',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/b3acbcd30b49f19aae0726d5ae67bce6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '9669b6d8face36ddee91fa8d72bcaef3',
      'native_key' => '9669b6d8face36ddee91fa8d72bcaef3',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/0d79b265440ace3590e4af803c4ab00a.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd10a888d8f4253f03dea6acda2861431',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/5c0403ea80538ff17ef3b6d604690884.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);