<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.1-pl
----------------------------------
Released on 2023-08-09

- Add some more type safety checks to the access token reading/saving

Google Drive Media Source 1.0.0-pl
----------------------------------
Released on 2023-02-07

- First public release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1b40f9bb1b55542aa293b60ba7a36688',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/129f39034d017d0feca25122076928d4.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '03eb8b8ecf9a14f58818eda716c13de7',
      'native_key' => '03eb8b8ecf9a14f58818eda716c13de7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/37ab59ce15ec90ff5cc9eb939000126d.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '3748ef8bf6ba3ccfa51727cff566231e',
      'native_key' => '3748ef8bf6ba3ccfa51727cff566231e',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/bbb005f5dc241cef1a62d388ad191dfe.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'bb78ba475a6f35b77cf16a63f1305482',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/f49efbcde6ec71dcf36fd1bb6a561ab5.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);