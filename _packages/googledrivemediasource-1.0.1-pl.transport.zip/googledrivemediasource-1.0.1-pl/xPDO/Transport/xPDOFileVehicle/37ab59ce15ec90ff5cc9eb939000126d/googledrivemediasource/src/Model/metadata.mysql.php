<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'modmore\\GoogleDriveMediaSource\\Model',
    'namespacePrefix' => 'modmore\\GoogleDriveMediaSource',
    'class_map' => 
    array (
        'MODX\\Revolution\\Sources\\modMediaSource' => 
        array (
            0 => 'modmore\\GoogleDriveMediaSource\\Model\\GoogleDriveMediaSource',
        ),
    ),
);