<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Proprietary until project completed and paid in full. Afterwards, MIT as included below.

MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.0-rc1
-----------------------------------
Released on 2022-11-03

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '79b81d8cce8d248ef408df658ba021da',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/aa50ad20132adec07b3df2d30e38262a.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '53879cd4f32cc934b89309d2780589e1',
      'native_key' => '53879cd4f32cc934b89309d2780589e1',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/4171c1159bfff3a39a93e65883a2e4c0.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '6abd9a9d60aad893616a579a7b119e39',
      'native_key' => '6abd9a9d60aad893616a579a7b119e39',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/b8f4af52300e854d3e28c8a18c540dc8.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '7d2b6b1d2281b12b7c480a85811ca89d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/d08b91a7e36f03c27ae267a84cc11c83.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);