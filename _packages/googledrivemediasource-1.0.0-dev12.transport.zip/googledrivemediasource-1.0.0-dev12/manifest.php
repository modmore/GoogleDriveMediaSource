<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Proprietary until project completed and paid in full. Afterwards, MIT as included below.

MIT License

Copyright (c) 2022 modmore

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Google Drive Media Source for MODX
---

After installation, please refer to the documentation (@todo insert link)
for setup instructions.
',
    'changelog' => 'Google Drive Media Source 1.0.0-rc1
-----------------------------------
Released on 2022-11-03

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'bd5ca4fdffe9f90fcff8018db7be4f2e',
      'native_key' => 'googledrivemediasource',
      'filename' => 'MODX/Revolution/modNamespace/2524db740b9e507a20d9e0258a73f48d.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '6d99c71f7f1b2af0301a3907c2d7ee8d',
      'native_key' => '6d99c71f7f1b2af0301a3907c2d7ee8d',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1097aaf44a4d14b2da26d07d9853e07b.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '4bd3e190b6cdb5dbc74142bf4306691b',
      'native_key' => '4bd3e190b6cdb5dbc74142bf4306691b',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/093a18ebc60bc86f15a23ddad86013b8.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd6b9781959993960f141ddeb66001f0d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/f42881f2e41a2d5c2c111fa3ca94213e.vehicle',
      'namespace' => 'googledrivemediasource',
    ),
  ),
);